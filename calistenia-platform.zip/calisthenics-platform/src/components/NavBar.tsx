"use client";

import Link from "next/link";
import { useSession, signOut } from "next-auth/react";
import { useState } from "react";

export default function NavBar() {
  const { data: session } = useSession();
  const [open, setOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 border-b border-white/10 bg-ink/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
        <Link href="/" className="text-sm font-semibold uppercase tracking-widest2 text-bone">
          Calistenia
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          <Link href="/#programas" className="text-xs uppercase tracking-widest text-bone/70 hover:text-bone">
            Programas
          </Link>
          <Link href="/coach" className="text-xs uppercase tracking-widest text-bone/70 hover:text-bone">
            Coach
          </Link>
          {session?.user?.role === "ADMIN" && (
            <Link href="/admin" className="text-xs uppercase tracking-widest text-bone/70 hover:text-bone">
              Admin
            </Link>
          )}
          {session?.user ? (
            <>
              <Link href="/cuenta" className="text-xs uppercase tracking-widest text-bone/70 hover:text-bone">
                Mi cuenta
              </Link>
              <button
                onClick={() => signOut({ callbackUrl: "/" })}
                className="rounded-full border border-white/20 px-4 py-2 text-xs uppercase tracking-widest text-bone hover:bg-white/10"
              >
                Salir
              </button>
            </>
          ) : (
            <Link
              href="/login"
              className="rounded-full border border-white/20 px-4 py-2 text-xs uppercase tracking-widest text-bone hover:bg-white/10"
            >
              Ingresar
            </Link>
          )}
        </nav>

        <button
          className="flex flex-col gap-1.5 md:hidden"
          onClick={() => setOpen(!open)}
          aria-label="Menú"
        >
          <span className="h-px w-6 bg-bone" />
          <span className="h-px w-6 bg-bone" />
        </button>
      </div>

      {open && (
        <div className="flex flex-col gap-1 border-t border-white/10 bg-ink px-5 py-4 md:hidden">
          <Link href="/#programas" className="py-2 text-sm uppercase tracking-widest text-bone/80" onClick={() => setOpen(false)}>
            Programas
          </Link>
          <Link href="/coach" className="py-2 text-sm uppercase tracking-widest text-bone/80" onClick={() => setOpen(false)}>
            Coach
          </Link>
          {session?.user?.role === "ADMIN" && (
            <Link href="/admin" className="py-2 text-sm uppercase tracking-widest text-bone/80" onClick={() => setOpen(false)}>
              Admin
            </Link>
          )}
          {session?.user ? (
            <>
              <Link href="/cuenta" className="py-2 text-sm uppercase tracking-widest text-bone/80" onClick={() => setOpen(false)}>
                Mi cuenta
              </Link>
              <button
                onClick={() => signOut({ callbackUrl: "/" })}
                className="py-2 text-left text-sm uppercase tracking-widest text-bone/80"
              >
                Salir
              </button>
            </>
          ) : (
            <Link href="/login" className="py-2 text-sm uppercase tracking-widest text-bone/80" onClick={() => setOpen(false)}>
              Ingresar
            </Link>
          )}
        </div>
      )}
    </header>
  );
}
