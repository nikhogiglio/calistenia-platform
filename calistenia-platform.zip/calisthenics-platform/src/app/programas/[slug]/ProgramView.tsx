"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useSession } from "next-auth/react";

type Exercise = {
  id: string;
  name: string;
  sets: string;
  repsTime: string;
  rest: string;
  videoUrl: string | null;
};

type Day = { id: string; title: string; exercises: Exercise[] };

type Level = {
  id: string;
  name: string;
  goals: string | null;
  experience: string | null;
  schedule: string | null;
  warmup: string | null;
  days: Day[];
};

type Program = {
  id: string;
  slug: string;
  title: string;
  subtitle: string | null;
  description: string;
  price: number;
  imageUrl: string | null;
  levels: Level[];
};

export default function ProgramView({
  program,
  hasAccess,
  isLoggedIn,
}: {
  program: Program;
  hasAccess: boolean;
  isLoggedIn: boolean;
}) {
  const router = useRouter();
  const params = useSearchParams();
  const { data: session } = useSession();
  const [activeLevel, setActiveLevel] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const success = params.get("success");

  async function handleBuy() {
    setError("");
    if (!isLoggedIn) {
      router.push(`/login?next=/programas/${program.slug}`);
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ programId: program.id }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Error al iniciar el pago.");
      window.location.href = data.url;
    } catch (e: any) {
      setError(e.message);
      setLoading(false);
    }
  }

  const level = program.levels[activeLevel];

  return (
    <div>
      <section className="relative flex min-h-[45vh] flex-col items-center justify-end overflow-hidden px-6 pb-12 pt-32 text-center">
        {program.imageUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={program.imageUrl}
            alt={program.title}
            className="absolute inset-0 h-full w-full object-cover opacity-40"
          />
        ) : (
          <div className="absolute inset-0 bg-gradient-to-b from-graphite to-ink" />
        )}
        <div className="relative z-10">
          <p className="mb-2 text-xs uppercase tracking-widest text-bone/60">{program.subtitle}</p>
          <h1 className="text-3xl font-semibold uppercase tracking-tight md:text-5xl">
            {program.title}
          </h1>
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-5 py-12">
        <p className="text-sm leading-relaxed text-bone/70">{program.description}</p>

        {success && (
          <div className="mt-6 rounded-lg border border-green-500/30 bg-green-500/10 px-4 py-3 text-sm text-green-300">
            ¡Pago exitoso! Ya tienes acceso completo al programa.
          </div>
        )}
        {error && (
          <div className="mt-6 rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300">
            {error}
          </div>
        )}

        <div className="mt-8 flex items-center justify-between rounded-2xl border border-white/10 bg-charcoal px-6 py-5">
          <div>
            <p className="text-xs uppercase tracking-widest text-bone/50">Precio</p>
            <p className="text-2xl font-semibold">${(program.price / 100).toFixed(0)}</p>
          </div>
          {hasAccess ? (
            <span className="rounded-full bg-bone px-6 py-3 text-xs font-semibold uppercase tracking-widest text-ink">
              Desbloqueado
            </span>
          ) : (
            <button
              onClick={handleBuy}
              disabled={loading}
              className="rounded-full bg-bone px-6 py-3 text-xs font-semibold uppercase tracking-widest text-ink hover:opacity-90 disabled:opacity-50"
            >
              {loading ? "Cargando..." : "Comprar programa"}
            </button>
          )}
        </div>

        {/* Level selector */}
        <div className="mt-12">
          <div className="flex gap-2 overflow-x-auto pb-2">
            {program.levels.map((l, i) => (
              <button
                key={l.id}
                onClick={() => setActiveLevel(i)}
                className={`whitespace-nowrap rounded-full border px-5 py-2 text-xs uppercase tracking-widest transition ${
                  activeLevel === i
                    ? "border-bone bg-bone text-ink"
                    : "border-white/20 text-bone/60 hover:border-white/40"
                }`}
              >
                {l.name}
              </button>
            ))}
          </div>

          {!hasAccess ? (
            <div className="mt-8 rounded-2xl border border-white/10 bg-charcoal p-8 text-center">
              <p className="text-sm text-bone/60">
                Compra el programa para desbloquear los {program.levels.length} niveles completos,
                con todos los días de entrenamiento y videos demostrativos.
              </p>
            </div>
          ) : level ? (
            <div className="mt-8 space-y-8">
              <div className="grid gap-4 rounded-2xl border border-white/10 bg-charcoal p-6 sm:grid-cols-2">
                {level.goals && (
                  <div>
                    <p className="mb-1 text-xs uppercase tracking-widest text-bone/50">
                      Training Goals
                    </p>
                    <p className="text-sm text-bone/80">{level.goals}</p>
                  </div>
                )}
                {level.experience && (
                  <div>
                    <p className="mb-1 text-xs uppercase tracking-widest text-bone/50">
                      Recommended Experience
                    </p>
                    <p className="text-sm text-bone/80">{level.experience}</p>
                  </div>
                )}
                {level.schedule && (
                  <div>
                    <p className="mb-1 text-xs uppercase tracking-widest text-bone/50">
                      Weekly Schedule
                    </p>
                    <p className="text-sm text-bone/80">{level.schedule}</p>
                  </div>
                )}
                {level.warmup && (
                  <div>
                    <p className="mb-1 text-xs uppercase tracking-widest text-bone/50">Warm-up</p>
                    <p className="text-sm text-bone/80">{level.warmup}</p>
                  </div>
                )}
              </div>

              {level.days.map((day) => (
                <div key={day.id} className="rounded-2xl border border-white/10 bg-charcoal p-6">
                  <h3 className="mb-4 text-lg font-semibold uppercase tracking-wide">
                    {day.title}
                  </h3>
                  <div className="space-y-3">
                    {day.exercises.map((ex) => (
                      <div
                        key={ex.id}
                        className="flex flex-col gap-2 rounded-xl border border-white/5 bg-graphite/50 p-4 sm:flex-row sm:items-center sm:justify-between"
                      >
                        <div>
                          <p className="text-sm font-medium">{ex.name}</p>
                          <p className="text-xs text-bone/50">
                            {ex.sets} sets · {ex.repsTime} · descanso {ex.rest}
                          </p>
                        </div>
                        {ex.videoUrl && (
                          <a
                            href={ex.videoUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="w-fit rounded-full border border-white/20 px-4 py-1.5 text-xs uppercase tracking-widest hover:bg-white/10"
                          >
                            Ver video
                          </a>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          ) : null}
        </div>
      </section>
    </div>
  );
}
