import { NextResponse } from "next/server";
import { headers } from "next/headers";
import { stripe } from "@/lib/stripe";
import { prisma } from "@/lib/prisma";
import Stripe from "stripe";

export const runtime = "nodejs";

export async function POST(req: Request) {
  const body = await req.text();
  const sig = headers().get("stripe-signature");
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  let event: Stripe.Event;
  try {
    if (!sig || !webhookSecret) throw new Error("Falta configuración del webhook.");
    event = stripe.webhooks.constructEvent(body, sig, webhookSecret);
  } catch (err) {
    console.error("Webhook signature error:", err);
    return NextResponse.json({ error: "Firma inválida." }, { status: 400 });
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;
    const userId = session.metadata?.userId;
    const programId = session.metadata?.programId;

    if (userId && programId) {
      await prisma.purchase.upsert({
        where: { userId_programId: { userId, programId } },
        update: {
          status: "paid",
          stripeCheckoutSession: session.id,
          stripePaymentIntent:
            typeof session.payment_intent === "string" ? session.payment_intent : undefined,
        },
        create: {
          userId,
          programId,
          status: "paid",
          amount: session.amount_total || 0,
          currency: session.currency || "usd",
          stripeCheckoutSession: session.id,
          stripePaymentIntent:
            typeof session.payment_intent === "string" ? session.payment_intent : undefined,
        },
      });
    }
  }

  return NextResponse.json({ received: true });
}
